conda activate DL; cd /home/HaotianF/Exp/Ours/baselines/exp_framwork; nohup python main.py --device cuda:0 --logs_save_dir /home/HaotianF/Exp/Results --experiment_description TS2Vec --method_name TS2Vec --run_description Electricity --training_mode self_supervised --seed 123 --selected_dataset Electricity >> TS2Vec_Electricity.log 2>&1 &


